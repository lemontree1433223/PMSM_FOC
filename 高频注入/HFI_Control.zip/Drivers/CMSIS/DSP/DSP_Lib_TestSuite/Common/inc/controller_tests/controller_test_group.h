#ifndef _CONTROLLER_TEST_GROUP_H_
#define _CONTROLLER_TEST_GROUP_H_

/*--------------------------------------------------------------------------------*/
/* Declare Test Group */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(controller_tests);

#endif /* _CONTROLLER_TEST_GROUP_H_ */
